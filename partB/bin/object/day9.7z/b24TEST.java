package object.day9;

public class b24TEST {

    public static void main(String[] args) {
        
        Shape sh = new Shape();
        System.out.println(sh + ",넓이 = " + sh.area());

        System.out.println("// 추상클래스 테스트 //");

        AbstractShape tri = new ATriangle(0, 0)

      




    }

}
